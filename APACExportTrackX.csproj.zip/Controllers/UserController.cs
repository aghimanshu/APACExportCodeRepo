﻿using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using System.Globalization;

namespace APACExportTrackX.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index(string ActivityId)
        {
            var country = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var activity = _context.ActivityMaster.Where(x => x.Id == ActivityId && x.IsDelete == false && x.IsActive == true).FirstOrDefault();

            if (activity.ActivityType == "File")
            {
                activity.NameOfActivity += " (F)";
            }
            else
            {
                activity.NameOfActivity += " (H)";
            }

            ViewBag.Country = country;
            ViewBag.Activity = activity;
            return View();
        }

        public IActionResult Files(string activityId)
        {
            //ViewData["CountryId"] = _context.CountryMaster.ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsActive == true && x.IsDelete == false).ToList();
            //ViewBag.Activity = activity;
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            //ViewBag.Countries = _context.CountryMaster.OrderBy(x => x.CountryName).ToList();
            return View();

        }

        //[HttpPost]
        //public IActionResult GetFiles(string country, string fileNumber, string activity, string search, string type)
        //{
        //    int totalRecord = 0;
        //    int filterRecord = 0;
        //    int hblrecord = 0;
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //    var searchValue = Request.Form["search[value]"].FirstOrDefault();
        //    int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
        //    int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //    var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

        //    var fileData = _context.ContainerMaster
        //        .Include(x => x.FileMaster)
        //        .Include(x => x.FileActivityLogs)
        //            .ThenInclude(x => x.ApplicationUser)
        //        .Select(a => new FileDashModel
        //        {
        //            Id = a.FileMaster.Id,
        //            FileLogId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .Select(y => y.Id)
        //                .FirstOrDefault(),
        //            EnterDate = a.FileMaster.EnterDate,
        //            FileNumber = a.FileMaster.FileNumber.Substring(0, a.FileMaster.FileNumber.Length - 6),
        //            POD = a.FileMaster.CountryMaster.CountryName,
        //            ETD = a.FileMaster.ETD,
        //            ETAPOD = a.FileMaster.ETAPOD,
        //            ETA = a.FileMaster.ETA,
        //            ATD = a.FileMaster.ATD,
        //            SICutOff = a.SICutOff,
        //            ShippingLine = a.FileMaster.ShippingLine,
        //            FileContact = a.FileMaster.FileContact,
        //            UserId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().ApplicationUser.UserName ?? "",
        //            StatusId = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            StatusCompleted = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().EndDate,
        //            ActivityId = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Activity.NameOfActivity ?? "",
        //            ActivityType = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                    .FirstOrDefault().Activity.ActivityType ?? "",
        //            ContainerNo = a.ContainerNo,
        //            ContainerId = a.Id,
        //            //TotalHBL = a.FileMaster.TotalBL,
        //            Comment = a.FileActivityLogs
        //                    .Where(y => y.ContainerId == a.Id)
        //                    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                    .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                   .FirstOrDefault().Comment,
        //            //Roe = a.FileActivityLogs
        //            //        .Where(y => y.ContainerId == a.Id)
        //            //        .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //            //        .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //            //       .FirstOrDefault().Roe,
        //            Roe = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Roe != null) // Filter for non-null Roe
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Roe,
        //            CurrentUser = userName,
        //            EndDate = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id)
        //                .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
        //                .ThenBy(y => y.EndDate)
        //                .FirstOrDefault().EndDate,
        //            TallySheetId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TallySheetCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            MblReviewId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            MblReviewCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            TblProcessingId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            BLRequestId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TblProcessingCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            BLRequestCompleted = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().EndDate,
        //            TallySheetComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            MblReviewComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            TblProcessingComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            BLRequestComment = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Comment ?? "",
        //            CarrierRequest = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            CarrierRequestCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().EndDate,
        //            BlRequestId = a.FileActivityLogs
        //                .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
        //                .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == activity)
        //                .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            BlRequestCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "BL Request")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
        //            .FirstOrDefault().EndDate,
        //            TBLProcessing = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TBLProcessCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
        //            .FirstOrDefault().EndDate,
        //            TallySheetChecking = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            TallySheetCheckingCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
        //            .FirstOrDefault().EndDate,
        //            SIToCarrier = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            SIToCarrierCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
        //            .FirstOrDefault().EndDate,
        //            MBLReview = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "MBL Review")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            MBLReviewsCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "MBL Review")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
        //            .FirstOrDefault().EndDate,
        //            Invoice = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            InvoiceCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
        //            .FirstOrDefault().EndDate,
        //            FinalBL = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            FinalBLCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
        //            .FirstOrDefault().EndDate,
        //            PreAlert = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            PreAlertCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
        //            .FirstOrDefault().EndDate,
        //            Permit = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Permit")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
        //            .FirstOrDefault().Status.Status ?? "UnAllocated",
        //            PermitCompleted = a.FileActivityLogs
        //            .Where(y => y.Activity.NameOfActivity == "Permit")
        //            .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
        //            .FirstOrDefault().EndDate,
        //            LBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count(),
        //            TBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
        //            TotalHBL = a.HBLMasters.Where(y => y.ContainerId == a.Id).Count() != 0 ? (a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : a.FileMaster.TotalBL

        //        }).AsQueryable();

        //    IQueryable<FileDashModel> data = fileData.AsQueryable();
        //    DateTime date = DateTime.UtcNow;
        //    if (!string.IsNullOrEmpty(fileNumber))
        //    {
        //        data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
        //    }
        //    if (date != null)
        //    {
        //        data = data.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
        //    }
        //    if (activity == "BL Request")
        //    {
        //        data = data.Where(x => x.BlRequestId != "Completed" && x.CarrierRequest == "Completed");
        //    }
        //    if (activity == "SI To Carrier")
        //    {
        //        data = data.Where(x => x.SIToCarrier != "Completed" && x.BlRequestId == "Completed");
        //    }
        //    else if (activity == "Final BL To Invoices Customer")
        //    {
        //        data = data.Where(x => x.FinalBL != "Completed" && x.SIToCarrier == "Completed");
        //    }
        //    else if (activity == "Pre-Alert")
        //    {
        //        data = data.Where(x => x.FinalBL == "Completed" && x.PreAlert != "Completed");
        //    }
        //    else if (activity == "Permit")
        //    {
        //        data = data.Where(x => x.PreAlert == "Completed" && x.Permit != "Completed");
        //    }
        //    else if (activity == "Invoices To POD Agent")
        //    {
        //        data = data.Where(x => x.Permit == "Completed" && x.Invoice != "Completed");
        //    }
        //    else if (activity == "Tally Sheet")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.TallySheetId != "Completed");
        //    }
        //    else if (activity == "MBL Review")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.MblReviewId != "Completed");
        //    }
        //    else if (activity == "TBL Processing")
        //    {
        //        data = data.Where(x => x.CarrierRequest == "Completed" && x.TBLProcessing != "Completed");
        //    }
        //    else
        //    {
        //        data = data.Where(x => (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
        //    }

        //    if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
        //    {
        //        data = data.Where(x => x.POD == country);
        //    }

        //    if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //    {
        //        data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    }
        //    else if (activity == "SI To Carrier")
        //    {
        //        sortColumn = "siCutOff";
        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }
        //    else if (activity == "Final BL To Invoices Customer")
        //    {
        //        sortColumn = "etd";
        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }
        //    else
        //    {
        //        sortColumn = "enterDate";

        //        data = data.OrderByDescending(x => x.StatusId == "Pending" && x.UserId == userName).ThenBy(sortColumn + " " + sortColumnDirection);
        //    }

        //    var files = data.Skip(skip).Take(pageSize).ToList();

        //    return Json(new
        //    {
        //        draw = draw,
        //        recordsTotal = fileData.Count(),
        //        recordsFiltered = files.Count(),
        //        data = files
        //    });

        //}

        [HttpPost]
        public IActionResult GetFiles(string country, string fileNumber, string activity, string activityId, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            //var fileData = _context.ContainerMaster.Where(x => x.SICutOff >= date.Date - TimeSpan.FromDays(10) || x.SICutOff == null)
            var fileData = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date - TimeSpan.FromDays(10) || x.SICutOff == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(a => new FileDashModel
                {
                    Id = a.FileMaster.Id,
                    FileLogId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id)
                        .Select(y => y.Id)
                        .FirstOrDefault(),
                    EnterDate = a.FileMaster.EnterDate,
                    FileNumber = a.FileMaster.FileNumber.Substring(0, a.FileMaster.FileNumber.Length - 6),
                    POD = a.FileMaster.CountryMaster.CountryName,
                    ETD = a.FileMaster.ETD,
                    ETAPOD = a.FileMaster.ETAPOD,
                    ETA = a.FileMaster.ETA,
                    ATD = a.FileMaster.ATD,
                    SICutOff = a.SICutOff,
                    ShippingLine = a.FileMaster.ShippingLine,
                    FileContact = a.FileMaster.FileContact,
                    UserId = a.FileActivityLogs.Where(y => y.ContainerId == a.Id && y.ActivityId == activityId).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                            .FirstOrDefault().Status.Status ?? "UnAllocated",
                    StatusCompleted = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                            .FirstOrDefault().EndDate,
                    ActivityId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                            .FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                            .FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = a.ContainerNo,
                    ContainerId = a.Id,
                    //TotalHBL = a.FileMaster.TotalBL,
                    Comment = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                           .FirstOrDefault().Comment,
                    //Roe = a.FileActivityLogs
                    //        .Where(y => y.ContainerId == a.Id)
                    //        .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //        .ThenByDescending(y => y.Activity.NameOfActivity == activity)
                    //       .FirstOrDefault().Roe,
                    Roe = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Roe != null && y.ActivityId == activityId)
                        .FirstOrDefault().Roe,
                    CurrentUser = userName,
                    StartDate = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                        .FirstOrDefault().StartDate, 
                    EndDate = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.ActivityId == activityId)
                        .FirstOrDefault().EndDate,
                    TallySheetId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    TallySheetCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
                        .FirstOrDefault().EndDate,
                    MblReviewId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    MblReviewCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
                        .FirstOrDefault().EndDate,
                    TblProcessingId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    BLRequestId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    TblProcessingCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
                        .FirstOrDefault().EndDate,
                    BLRequestCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().EndDate,
                    TallySheetComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
                        .FirstOrDefault().Comment ?? "",
                    MblReviewComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
                        .FirstOrDefault().Comment ?? "",
                    TblProcessingComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
                        .FirstOrDefault().Comment ?? "",
                    BLRequestComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().Comment ?? "",
                    CarrierRequest = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Carrier Request")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    CarrierRequestCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Carrier Request")
                    .FirstOrDefault().EndDate,
                    BLRequest = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //BLRequestCompleted = a.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "BL Request")
                    //.FirstOrDefault().EndDate,
                    TBLProcessing = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "TBL Processing")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    TBLProcessCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "TBL Processing")
                    .FirstOrDefault().EndDate,
                    TallySheetChecking = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    TallySheetCheckingCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
                    .FirstOrDefault().EndDate,
                    SIToCarrier = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    .FirstOrDefault().EndDate,
                    MBLReview = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "MBL Review")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    MBLReviewsCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "MBL Review")
                    .FirstOrDefault().EndDate,
                    Invoice = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    InvoiceCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    .FirstOrDefault().EndDate,
                    FinalBL = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    FinalBLCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    .FirstOrDefault().EndDate,
                    PreAlert = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlertCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
                    .FirstOrDefault().EndDate,
                    Permit = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Permit")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    PermitCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Permit")
                    .FirstOrDefault().EndDate,
                    LBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    TBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    TotalHBL = a.HBLMasters.Where(y => y.ContainerId == a.Id).Count() != 0 ? (a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : a.FileMaster.TotalBL

                }).AsQueryable();

            IQueryable<FileDashModel> data = fileData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                //data = data.Where(x => x.SICutOff >= date.Date - TimeSpan.FromDays(10) || x.SICutOff == null);
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff == null);
            }
            if (activity == "BL Request")
            {
                data = data.Where(x => x.BLRequestId != "Completed" && x.CarrierRequest == "Completed");
            }
            else if (activity == "SI To Carrier")
            {
                data = data.Where(x => x.SIToCarrier != "Completed" && x.CarrierRequest == "Completed");
            }
            else if (activity == "Final BL To Invoices Customer")
            {
                data = data.Where(x => x.FinalBL != "Completed" && x.SIToCarrier == "Completed");
            }
            else if (activity == "Pre-Alert")
            {
                data = data.Where(x => x.FinalBL == "Completed" && x.PreAlert != "Completed");
            }
            else if (activity == "Permit")
            {
                data = data.Where(x => x.PreAlert == "Completed" && x.Permit != "Completed");
            }
            else if (activity == "Invoices To POD Agent")
            {
                data = data.Where(x => x.Permit == "Completed" && x.Invoice != "Completed");
            }
            else if (activity == "Tally Sheet")
            {
                data = data.Where(x => x.CarrierRequest == "Completed" && x.TallySheetId != "Completed");
            }
            else if (activity == "MBL Review")
            {
                data = data.Where(x => x.CarrierRequest == "Completed" && x.MblReviewId != "Completed");
            }
            else if (activity == "TBL Processing")
            {
                data = data.Where(x => x.CarrierRequest == "Completed" && x.TBLProcessing != "Completed");
            }
            else
            {
                data = data.Where(x => (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (activity == "SI To Carrier")
            {
                sortColumn = "siCutOff";
                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }
            else if (activity == "Final BL To Invoices  Customer")
            {
                sortColumn = "etd";
                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";

                data = data.OrderByDescending(x => x.StatusId == "Pending").ThenBy(sortColumn + " " + sortColumnDirection);
            }

            //const string ISTTimeZoneId = "India Standard Time";
            //var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            data = data.Select(a => new FileDashModel
            {
                Id = a.Id,
                FileLogId = a.FileLogId,
                EnterDate = a.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EnterDate.Value, sgtTimeZone) : (DateTime?)null,
                FileNumber = a.FileNumber,
                POD = a.POD,
                ETD = a.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETD.Value, sgtTimeZone) : (DateTime?)null,
                ETAPOD = a.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETAPOD.Value, sgtTimeZone) : (DateTime?)null,
                ETA = a.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETA.Value, sgtTimeZone) : (DateTime?)null,
                ATD = a.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ATD.Value, sgtTimeZone) : (DateTime?)null,
                SICutOff = a.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                ShippingLine = a.ShippingLine,
                FileContact = a.FileContact,
                UserId = a.UserId,
                StatusId = a.StatusId,
                StatusCompleted = a.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EnterDate.Value, sgtTimeZone) : (DateTime?)null,
                ActivityId = a.ActivityId,
                ActivityType = a.ActivityType,
                ContainerNo = a.ContainerNo,
                ContainerId = a.ContainerId,
                Comment = a.Comment,
                Roe = a.Roe,
                CurrentUser = a.CurrentUser,
                StartDate = a.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.StartDate.Value, sgtTimeZone) : (DateTime?)null,
                EndDate = a.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EndDate.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetId = a.TallySheetId,
                TallySheetCompleted = a.TallySheetCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.TallySheetCompleted.Value, sgtTimeZone) : (DateTime?)null,
                MblReviewId = a.MblReviewId,
                MblReviewCompleted = a.MblReviewCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.MblReviewCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TblProcessingId = a.TblProcessingId,
                BLRequestId = a.BLRequestId,
                TblProcessingCompleted = a.TblProcessingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.TblProcessingCompleted.Value, sgtTimeZone) : (DateTime?)null,
                BLRequestCompleted = a.BLRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.BLRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetComment = a.TallySheetComment,
                MblReviewComment = a.MblReviewComment,
                TblProcessingComment = a.TblProcessingComment,
                BLRequestComment = a.BLRequestComment,
                CarrierRequest = a.CarrierRequest,
                CarrierRequestCompleted = a.CarrierRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.CarrierRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
                BLRequest = a.BLRequest,
                TBLProcessing = a.TBLProcessing,
                TBLProcessCompleted = a.TBLProcessCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.TBLProcessCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetChecking = a.TallySheetChecking,
                TallySheetCheckingCompleted = a.TallySheetCheckingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.TallySheetCheckingCompleted.Value, sgtTimeZone) : (DateTime?)null,
                SIToCarrier = a.SIToCarrier,
                SIToCarrierCompleted = a.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SIToCarrierCompleted.Value, sgtTimeZone) : (DateTime?)null,
                MBLReview = a.MBLReview,
                MBLReviewsCompleted = a.MBLReviewsCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.MBLReviewsCompleted.Value, sgtTimeZone) : (DateTime?)null,
                Invoice = a.Invoice,
                InvoiceCompleted = a.InvoiceCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.InvoiceCompleted.Value, sgtTimeZone) : (DateTime?)null,
                FinalBL = a.FinalBL,
                FinalBLCompleted = a.FinalBLCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.FinalBLCompleted.Value, sgtTimeZone) : (DateTime?)null,
                PreAlert = a.PreAlert,
                PreAlertCompleted = a.PreAlertCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PreAlertCompleted.Value, sgtTimeZone) : (DateTime?)null,
                Permit = a.Permit,
                PermitCompleted = a.PermitCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PermitCompleted.Value, sgtTimeZone) : (DateTime?)null,
                LBL = a.LBL,
                TBL = a.TBL,
                TotalHBL = a.TotalHBL

            }).AsQueryable();

            //var files = data.Skip(skip).Take(pageSize).ToList();
            var files = data.ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });

        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }

        [HttpGet]
        public IActionResult HBL(string activityId, string fileNumber)
        {
            ViewData["CountryId"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLs(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var hblData = _context.HBLMaster
                .Include(x => x.HBLActivityLogs)
                .Include(x => x.ContainerMaster)
                .Include(x => x.ContainerMaster.FileMaster.CountryMaster)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    HBLNumber = x.HBLNumber,
                    FileId = x.Id,
                    EnterDate = x.EnterDate,
                    POD = x.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber.Substring(0, x.ContainerMaster.FileMaster.FileNumber.Length - 6),
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    CurrentUser = userid,
                    Activity = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Activity.NameOfActivity).FirstOrDefault() ?? "",
                    ActivityType = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Activity.ActivityType).FirstOrDefault() ?? "",
                    User = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.ApplicationUser.UserName).FirstOrDefault() ?? "",
                    Status = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Status.Status).FirstOrDefault() ?? "UnAllocated",
                    Comment = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.Comment).FirstOrDefault() ?? "",
                    StartDate = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.StartDate).FirstOrDefault(),
                    EndDate = x.HBLActivityLogs.OrderBy(y => y.Hbl.EnterDate).Select(y => y.EndDate).FirstOrDefault()
                }).AsQueryable();
            IQueryable<HBLDashViewModel> data = hblData.AsQueryable();

            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => string.IsNullOrEmpty(x.Activity) && string.IsNullOrEmpty(x.ActivityType) || x.Activity != activity && x.ActivityType != type);
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
            }

            var files = data.OrderBy(sortColumn + " " + sortColumnDirection).ToList();
            //.Skip(skip)
            //.Take(pageSize)
            //.ToList();
            //const string ISTTimeZoneId = "India Standard Time";
            //var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            files = files.Select(x => new HBLDashViewModel
            {
                Id = x.Id,
                HBLNumber = x.HBLNumber,
                FileId = x.Id,
                EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, sgtTimeZone) : (DateTime?)null,
                POD = x.POD,
                FileNumber = x.FileNumber,
                ContainerNo = x.ContainerNo,
                BookingNo = x.BookingNo,
                CustomerName = x.CustomerName,
                CurrentUser = x.CurrentUser,
                Activity = x.Activity,
                ActivityType = x.ActivityType,
                User = x.User,
                Status = x.Status,
                Comment = x.Comment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, sgtTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, sgtTimeZone) : (DateTime?)null,
            }).ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = hblData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
            var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            adhocHBL = adhocHBL.Select(x => new
            {

                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, sgtTimeZone) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();


            return Json(new { adhocHBL });
        }

        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
            var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
            .Include(activity => activity.Activity)
            .Include(status => status.Status)
            .Include(user => user.ApplicationUser)
            .Select(x => new
            {
                Id = x.Activity.Id,
                ActivityName = x.Activity.NameOfActivity,
                Status = x.Status.Status,
                ProcessedDate = x.EndDate,
                User = x.ApplicationUser.UserName,
                Comment = x.Comment == null ? "" : x.Comment,
            })
           .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
           .ToList();

            return Json(new { HBL });
        }

        [HttpGet]
        public IActionResult GetHblActivitiesData(string hblId)
        {
            ViewData["hblActivityList"] = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.HBLId == hblId).Select(x => new HBLActivityLogViewModel
            {
                HBLId = x.HBLId,
                HBLNumber = x.Hbl.HBLNumber == null ? "" : x.Hbl.HBLNumber,
                ActivityId = x.Activity.NameOfActivity,
                EndDate = x.EndDate,
                StatusId = x.Status.Status,
                Comment = x.Comment == null ? "" : x.Comment,
                UserId = x.ApplicationUser.CitrixId == null ? "" : x.ApplicationUser.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivitiesData(string hblno, string hbl)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblno).ToList();
            List<HBLActivityLogViewModel> hblActivityLog = new List<HBLActivityLogViewModel>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityLogViewModel
                {
                    HBLNumber = hblno == null ? "" : hblno,
                    ActivityId = item.Activity.NameOfActivity == null ? "" : item.Activity.NameOfActivity,
                    EndDate = item.EndDate,
                    StatusId = item.Status.Status,
                    UserId = item.ApplicationUser.CitrixId,

                });
            }
            return Json(hblActivityLog);
        }

        [HttpPost]
        public JsonResult AddFileActivities(FileActivityLogViewModel model, string button, string? statusValue, string? startDateValue, string? endDateValue, string? fileComments, string? roeValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var editData = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.ContainerId == model.ContainerId && x.ActivityId == model.ActivityId);
            var wip = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var wipId = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false)?.Id;
            var query = _context.StatusMaster.FirstOrDefault(x => x.Status == "Query" && x.IsActive == true && x.IsDelete == false)?.Id;
            var pending = _context.StatusMaster.FirstOrDefault(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false)?.Id;
            var completed = _context.StatusMaster.FirstOrDefault(x => x.Status == "Completed" && x.IsActive == true && x.IsDelete == false)?.Id;
            var completedWithQuery = _context.StatusMaster.FirstOrDefault(x => x.Status == "Completed With Query" && x.IsActive == true && x.IsDelete == false)?.Id;
            var SIToCarrier = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false)?.Id;
            var MBLReview = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "MBL Review" && x.IsActive == true && x.IsDelete == false)?.Id;
            var TBLProcessing = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "TBL Processing" && x.IsActive == true && x.IsDelete == false)?.Id;
            var TallySheet = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Tally Sheet" && x.IsActive == true && x.IsDelete == false)?.Id;
            var statusList = _context.StatusMaster.FirstOrDefault(x => x.Status == statusValue && x.IsActive == true && x.IsDelete == false);
            var fileList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.ContainerId == model.ContainerId && x.ActivityId == model.ActivityId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId && x.IsActive == true && x.IsDelete == false);

            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;
            if (model.StartDate != null)
            {
                DateTime startDate = DateTime.ParseExact(model.StartDate, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                model.StartDate = startDate.ToString("MM/dd/yyyy HH:mm");
            }

            if (model.SI != null)
            {
                DateTime si = DateTime.ParseExact(model.SI, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                model.SI = si.ToString("MM/dd/yyyy HH:mm");
            }
            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    if (model.StatusId != wip.Status || model.UserId == userName)
                    {
                        if (fileList != null)
                        {
                            fileList.ContainerId = model.ContainerId;
                            fileList.ActivityId = model.ActivityId;
                            fileList.StatusId = wip.Id;
                            fileList.UserId = userid;
                            fileList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            fileList.Roe = model.Roe;
                            _context.FileActivityLog.Update(fileList);
                        }
                        else
                        {
                            var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            if (containerData == null)
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    ContainerNo = model.ContainerNo,
                                    FileId = model.FileId,
                                    SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                                });
                                _context.SaveChanges();

                                containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            }

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = (model.StatusId != wip.Status) ? wip.Id : model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });
                            _context.SaveChanges();
                        }
                        _context.SaveChanges();
                        return Json("Success");
                    }
                    else
                    {
                        return Json("Activity is processed by another user");
                    }
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    var user = "";
                    if (model.StatusId == "UnAllocated" || statusValue == "UnAllocated")
                    {
                        user = null;
                    }
                    else
                    {
                        user = userid;
                    }
                    if (fileList != null)
                    {
                        fileList.ContainerId = model.ContainerId;
                        fileList.ActivityId = model.ActivityId;
                        fileList.StatusId = selectedStatusId;
                        fileList.UserId = user;
                        fileList.Roe = roeValue;
                        _context.FileActivityLog.Update(fileList);
                    }
                    else
                    {
                        var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                        if (containerData == null)
                        {
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                        }
                        else
                        {
                            containerData.ContainerNo = model.ContainerNo;
                            containerData.FileId = model.FileId;
                            containerData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                            _context.ContainerMaster.Update(containerData);
                        }

                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = containerData.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = user,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment,
                            Roe = roeValue
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                var containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));
                var carrierRequest = _context.ActivityMaster.Where(x => x.NameOfActivity == "Carrier Request" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var BLRequest = _context.ActivityMaster.Where(x => x.NameOfActivity == "BL Request" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var sIToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var tallySheets = _context.ActivityMaster.Where(x => x.NameOfActivity == "Tally Sheet" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var mblReviews = _context.ActivityMaster.Where(x => x.NameOfActivity == "MBL Review" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var tblProcessing = _context.ActivityMaster.Where(x => x.NameOfActivity == "TBL Processing" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var finalBL = _context.ActivityMaster.Where(x => x.NameOfActivity == "Final BL To Invoices Customer" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var preAlert = _context.ActivityMaster.Where(x => x.NameOfActivity == "Pre-Alert" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var permit = _context.ActivityMaster.Where(x => x.NameOfActivity == "Permit" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                var invoices = _context.ActivityMaster.Where(x => x.NameOfActivity == "Invoices To POD Agent" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();

                if (containerListData != null)
                {
                    containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    _context.ContainerMaster.Update(containerListData);
                }
                else
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        ContainerNo = model.ContainerNo,
                        FileId = model.FileId,
                        SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                    });
                    _context.SaveChanges();
                }
                containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));
                var lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId != TBLProcessing && x.ActivityId != MBLReview && x.ActivityId != TallySheet).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                var fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                if (ModelState.IsValid)
                {
                    if (BLRequest != null)
                    {
                        var hblList = _context.HBLActivityLog.Include(x => x.Hbl).Where(x => x.Hbl.ContainerId == containerListData.Id).ToList();
                        foreach (var hbl in hblList)
                        {
                            if (hbl.Status.Status != "Completed")
                            {
                                return Json("Please complete HBL activities.");
                            }
                        }

                        if (containerListData != null)
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();
                            var activities = new List<(string ActivityId, string StatusId, string Comment)>();
                            if (model.ActivityId == SIToCarrier)
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                (model.ActivityId, model.StatusId, model.Comment),
                                (TallySheet, model.TallySheetId, model.TallySheetComment),
                                (MBLReview, model.MBLReviewId, model.MBLReviewComment),
                                (TBLProcessing,  model.TBLProcessingId, model.TBLProcessingComment),
                                //(BLRequest,  model.BLRequestId, model.BLRequestComment)
                            };
                            }
                            else
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                (model.ActivityId, model.StatusId, model.Comment),
                            };
                            }

                            var activityIds = new List<string>
                                {
                                    MBLReview,
                                    TBLProcessing,
                                    TallySheet,
                                    //BLRequest
                                };
                            var statusIds = new List<string>
                                {
                                    completedWithQuery,
                                    completed,
                                    pending,
                                    query
                                };
                            List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
                            int count = 0;
                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                if (activityId != SIToCarrier)
                                {
                                    if (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query)
                                    {
                                        if (activityIds.Contains(activityId) && (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query))
                                        {
                                            fileActivityLog = _context.FileActivityLog.Where(x =>
                                            x.ContainerId == containerListData.Id &&
                                            x.ActivityId == activityId).ToList();

                                            count++;
                                        }

                                    }
                                }
                            }

                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                var fileLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.ContainerMaster)
                                    .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityId);
                                if (model.ActivityId == SIToCarrier)
                                {

                                    if (count > 2)
                                    {
                                        if (fileLog != null)
                                        {
                                            containerListData.ContainerNo = model.ContainerNo;
                                            containerListData.FileId = model.FileId;
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            fileLog.ActivityId = activityId;
                                            fileLog.StatusId = statusId;
                                            fileLog.UserId = userid;
                                            fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                            fileLog.EndDate = DateTime.UtcNow;
                                            fileLog.Comment = comment;
                                            fileLog.Roe = model.Roe;
                                            _context.FileActivityLog.Update(fileLog);
                                            _context.ContainerMaster.Update(containerListData);
                                            _context.SaveChanges();
                                        }
                                        else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing)
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                        else
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Tally Sheet and MBL Review activity.");
                                    }


                                }
                                else
                                {
                                    if (fileLog != null)
                                    {
                                        containerListData.ContainerNo = model.ContainerNo;
                                        containerListData.FileId = model.FileId;
                                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                        fileLog.ActivityId = activityId;
                                        fileLog.StatusId = statusId;
                                        fileLog.UserId = userid;
                                        fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                        fileLog.EndDate = DateTime.UtcNow;
                                        fileLog.Comment = comment;
                                        fileLog.Roe = model.Roe;
                                        _context.FileActivityLog.Update(fileLog);
                                        _context.ContainerMaster.Update(containerListData);
                                        _context.SaveChanges();
                                    }
                                    else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing || activityId == BLRequest)
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                            EndDate = DateTime.UtcNow,
                                            Comment = comment,
                                            Roe = model.Roe
                                        });
                                        _context.SaveChanges();
                                    }
                                }

                            }

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId != TBLProcessing && x.ActivityId != MBLReview && x.ActivityId != TallySheet /*&& x.ActivityId != BLRequest*/).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == carrierRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == BLRequest).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = BLRequest,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == BLRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = sIToCarrier,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = finalBL,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == finalBL)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == preAlert)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = permit,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == permit)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoices,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();

                            var containersListData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            var containerData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });

                            _context.SaveChanges();

                            if (fileActivityList != null)
                            {
                                if (lastActivity == BLRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = sIToCarrier,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var activityIds = new List<string>
                                {
                                    MBLReview,
                                    TBLProcessing,
                                    TallySheet
                                };
                                    var statusIds = new List<string>
                                {
                                    completed,
                                    completedWithQuery,
                                };
                                    var fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x =>
                                        x.ContainerId == containerListData.Id &&
                                        activityIds.Contains(x.ActivityId) &&
                                        statusIds.Contains(x.StatusId)).ToList();
                                    if (fileActivityLog != null)
                                    {
                                        var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                                        if (alreadyfileExist != null)
                                        {
                                            _context.FileActivityLog.Update(alreadyfileExist);
                                        }
                                        else
                                        {
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = finalBL,
                                                StatusId = null,
                                                UserId = null,
                                                StartDate = null,
                                                EndDate = null,
                                                Comment = null
                                            });
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Tally Sheet and MBL Review activity");
                                    }


                                }
                                else if (lastActivity == finalBL)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == preAlert)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = permit,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == permit)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = invoices,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                    }
                    else
                    {
                        if (containerListData != null)
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();
                            var activities = new List<(string ActivityId, string StatusId, string Comment)>();
                            if (model.ActivityId == SIToCarrier)
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                (model.ActivityId, model.StatusId, model.Comment),
                                (TallySheet, model.TallySheetId, model.TallySheetComment),
                                (MBLReview, model.MBLReviewId, model.MBLReviewComment),
                                (TBLProcessing,  model.TBLProcessingId, model.TBLProcessingComment),
                                //(BLRequest,  model.BLRequestId, model.BLRequestComment)
                            };
                            }
                            else
                            {
                                activities = new List<(string ActivityId, string StatusId, string Comment)>
                            {
                                (model.ActivityId, model.StatusId, model.Comment),
                            };
                            }

                            var activityIds = new List<string>
                                {
                                    MBLReview,
                                    TBLProcessing,
                                    TallySheet,
                                    //BLRequest
                                };
                            var statusIds = new List<string>
                                {
                                    completedWithQuery,
                                    completed,
                                    pending,
                                    query
                                };
                            List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
                            int count = 0;
                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                if (activityId != SIToCarrier)
                                {
                                    if (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query)
                                    {
                                        if (activityIds.Contains(activityId) && (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query))
                                        {
                                            fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x =>
                                            x.ContainerId == containerListData.Id &&
                                            x.ActivityId == activityId).ToList();

                                            count++;
                                        }

                                    }
                                }
                            }

                            foreach (var (activityId, statusId, comment) in activities)
                            {
                                var fileLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.ContainerMaster)
                                    .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityId);
                                if (model.ActivityId == SIToCarrier)
                                {

                                    if (count > 2)
                                    {
                                        if (fileLog != null)
                                        {
                                            containerListData.ContainerNo = model.ContainerNo;
                                            containerListData.FileId = model.FileId;
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            fileLog.ActivityId = activityId;
                                            fileLog.StatusId = statusId;
                                            fileLog.UserId = userid;
                                            fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                            fileLog.EndDate = DateTime.UtcNow;
                                            fileLog.Comment = comment;
                                            fileLog.Roe = model.Roe;
                                            _context.FileActivityLog.Update(fileLog);
                                            _context.ContainerMaster.Update(containerListData);
                                            _context.SaveChanges();
                                        }
                                        else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing)
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                        else
                                        {
                                            if (containerListData != null)
                                            {
                                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                                _context.ContainerMaster.Update(containerListData);
                                            }
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = activityId,
                                                StatusId = statusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = comment,
                                                Roe = model.Roe
                                            });
                                            _context.SaveChanges();
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Tally Sheet and MBL Review activity.");
                                    }


                                }
                                else
                                {
                                    if (fileLog != null)
                                    {
                                        containerListData.ContainerNo = model.ContainerNo;
                                        containerListData.FileId = model.FileId;
                                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                        fileLog.ActivityId = activityId;
                                        fileLog.StatusId = statusId;
                                        fileLog.UserId = userid;
                                        fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                        fileLog.EndDate = DateTime.UtcNow;
                                        fileLog.Comment = comment;
                                        fileLog.Roe = model.Roe;
                                        _context.FileActivityLog.Update(fileLog);
                                        _context.ContainerMaster.Update(containerListData);
                                        _context.SaveChanges();
                                    }
                                    else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing /*|| activityId == BLRequest*/)
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        if (containerListData != null)
                                        {
                                            containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                            _context.ContainerMaster.Update(containerListData);
                                        }
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = activityId,
                                            StatusId = statusId,
                                            UserId = null,
                                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                            EndDate = DateTime.UtcNow,
                                            Comment = comment,
                                            Roe = model.Roe
                                        });
                                        _context.SaveChanges();
                                    }
                                }

                            }

                            _context.SaveChanges();

                            lastActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId != TBLProcessing && x.ActivityId != MBLReview && x.ActivityId != TallySheet /*&& x.ActivityId != BLRequest*/).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                            fileActivityList = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                            var fileActivityLists = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                            if (fileActivityLists != null)
                            {
                                if (lastActivity == carrierRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == BLRequest).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = BLRequest,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == BLRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = sIToCarrier,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == sIToCarrier)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = finalBL,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == finalBL)
                                {

                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == preAlert)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = permit,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }

                                }
                                else if (lastActivity == permit)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = containerListData.Id,
                                            ActivityId = invoices,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                            {
                                FileLogId = model.FileLogId,
                                ActivityId = model.ActivityId,
                                StatusId = selectedStatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime(),
                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                Comment = fileComments,
                                Roe = roeValue
                            });
                            _context.SaveChanges();

                            var containersListData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            var containerData = _context.ContainerMaster
                                .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = model.ActivityId,
                                StatusId = model.StatusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });

                            _context.SaveChanges();

                            if (fileActivityList != null)
                            {
                                if (lastActivity == BLRequest)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = sIToCarrier,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == sIToCarrier)
                                {
                                    var activityIds = new List<string>
                                {
                                    MBLReview,
                                    TBLProcessing,
                                    TallySheet
                                };
                                    var statusIds = new List<string>
                                {
                                    completed,
                                    completedWithQuery,
                                };
                                    var fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x =>
                                        x.ContainerId == containerListData.Id &&
                                        activityIds.Contains(x.ActivityId) &&
                                        statusIds.Contains(x.StatusId)).ToList();
                                    if (fileActivityLog != null)
                                    {
                                        var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                                        if (alreadyfileExist != null)
                                        {
                                            _context.FileActivityLog.Update(alreadyfileExist);
                                        }
                                        else
                                        {
                                            _context.FileActivityLog.Add(new FileActivityLog
                                            {
                                                ContainerId = containerListData.Id,
                                                ActivityId = finalBL,
                                                StatusId = null,
                                                UserId = null,
                                                StartDate = null,
                                                EndDate = null,
                                                Comment = null
                                            });
                                        }
                                    }
                                    else
                                    {
                                        return Json("Please complete Tally Sheet and MBL Review activity");
                                    }


                                }
                                else if (lastActivity == finalBL)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = preAlert,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == preAlert)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = permit,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                                else if (lastActivity == permit)
                                {
                                    var alreadyfileExist = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                                    if (alreadyfileExist != null)
                                    {
                                        _context.FileActivityLog.Update(alreadyfileExist);
                                    }
                                    else
                                    {
                                        _context.FileActivityLog.Add(new FileActivityLog
                                        {
                                            ContainerId = fileActivityList.ContainerId,
                                            ActivityId = invoices,
                                            StatusId = null,
                                            UserId = null,
                                            StartDate = null,
                                            EndDate = null,
                                            Comment = null
                                        });
                                    }
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                    }

                    //    if (containerListData != null)
                    //{
                    //    _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                    //    {
                    //        FileLogId = model.FileLogId,
                    //        ActivityId = model.ActivityId,
                    //        StatusId = selectedStatusId,
                    //        UserId = userid,
                    //        StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                    //        EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                    //        Comment = fileComments,
                    //        Roe = roeValue
                    //    });
                    //    _context.SaveChanges();
                    //    var activities = new List<(string ActivityId, string StatusId, string Comment)>();
                    //    if (model.ActivityId == SIToCarrier)
                    //    {
                    //        activities = new List<(string ActivityId, string StatusId, string Comment)>
                    //        {
                    //            (model.ActivityId, model.StatusId, model.Comment),
                    //            (TallySheet, model.TallySheetId, model.TallySheetComment),
                    //            (MBLReview, model.MBLReviewId, model.MBLReviewComment),
                    //            (TBLProcessing,  model.TBLProcessingId, model.TBLProcessingComment),
                    //            (BLRequest,  model.BLRequestId, model.BLRequestComment)
                    //        };
                    //    }
                    //    else
                    //    {
                    //        activities = new List<(string ActivityId, string StatusId, string Comment)>
                    //        {
                    //            (model.ActivityId, model.StatusId, model.Comment),
                    //        };
                    //    }

                    //    var activityIds = new List<string>
                    //            {
                    //                MBLReview,
                    //                TBLProcessing,
                    //                TallySheet,
                    //                BLRequest
                    //            };
                    //    var statusIds = new List<string>
                    //            {
                    //                completedWithQuery,
                    //                completed,
                    //                pending, 
                    //                query
                    //            };
                    //    List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
                    //    int count = 0;
                    //    foreach (var (activityId, statusId, comment) in activities)
                    //    {
                    //        if (activityId != SIToCarrier)
                    //        {
                    //            if (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query)
                    //            {
                    //                if (activityIds.Contains(activityId) && (statusId == completed || statusId == completedWithQuery || statusId == pending || statusId == query))
                    //                {
                    //                    fileActivityLog = _context.FileActivityLog.Where(x =>
                    //                    x.ContainerId == containerListData.Id &&
                    //                    x.ActivityId == activityId).ToList();

                    //                    count++;
                    //                }

                    //            }
                    //        }
                    //    }

                    //    foreach (var (activityId, statusId, comment) in activities)
                    //    {
                    //        var fileLog = _context.FileActivityLog.Include(x => x.ContainerMaster)
                    //            .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityId);
                    //        if (model.ActivityId == SIToCarrier)
                    //        {

                    //            if (count > 2)
                    //            {
                    //                if (fileLog != null)
                    //                {
                    //                    containerListData.ContainerNo = model.ContainerNo;
                    //                    containerListData.FileId = model.FileId;
                    //                    containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                    fileLog.ActivityId = activityId;
                    //                    fileLog.StatusId = statusId;
                    //                    fileLog.UserId = userid;
                    //                    fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                    //                    fileLog.EndDate = DateTime.UtcNow;
                    //                    fileLog.Comment = comment;
                    //                    fileLog.Roe = model.Roe;
                    //                    _context.FileActivityLog.Update(fileLog);
                    //                    _context.ContainerMaster.Update(containerListData);
                    //                    _context.SaveChanges();
                    //                }
                    //                else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing)
                    //                {
                    //                    if (containerListData != null)
                    //                    {
                    //                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                        _context.ContainerMaster.Update(containerListData);
                    //                    }
                    //                    _context.FileActivityLog.Add(new FileActivityLog
                    //                    {
                    //                        ContainerId = containerListData.Id,
                    //                        ActivityId = activityId,
                    //                        StatusId = statusId,
                    //                        UserId = userid,
                    //                        StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime(),
                    //                        EndDate = DateTime.UtcNow,
                    //                        Comment = comment,
                    //                        Roe = model.Roe
                    //                    });
                    //                    _context.SaveChanges();
                    //                }
                    //                else
                    //                {
                    //                    if (containerListData != null)
                    //                    {
                    //                        containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                        _context.ContainerMaster.Update(containerListData);
                    //                    }
                    //                    _context.FileActivityLog.Add(new FileActivityLog
                    //                    {
                    //                        ContainerId = containerListData.Id,
                    //                        ActivityId = activityId,
                    //                        StatusId = statusId,
                    //                        UserId = userid,
                    //                        StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                    //                        EndDate = DateTime.UtcNow,
                    //                        Comment = comment,
                    //                        Roe = model.Roe
                    //                    });
                    //                    _context.SaveChanges();
                    //                }
                    //            }
                    //            else
                    //            {
                    //                return Json("Please complete Tally Sheet and MBL Review activity.");
                    //            }


                    //        }
                    //        else
                    //        {
                    //            if (fileLog != null)
                    //            {
                    //                containerListData.ContainerNo = model.ContainerNo;
                    //                containerListData.FileId = model.FileId;
                    //                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                fileLog.ActivityId = activityId;
                    //                fileLog.StatusId = statusId;
                    //                fileLog.UserId = userid;
                    //                fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                    //                fileLog.EndDate = DateTime.UtcNow;
                    //                fileLog.Comment = comment;
                    //                fileLog.Roe = model.Roe;
                    //                _context.FileActivityLog.Update(fileLog);
                    //                _context.ContainerMaster.Update(containerListData);
                    //                _context.SaveChanges();
                    //            }
                    //            else if (activityId == TallySheet || activityId == MBLReview || activityId == TBLProcessing || activityId == BLRequest)
                    //            {
                    //                if (containerListData != null)
                    //                {
                    //                    containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                    _context.ContainerMaster.Update(containerListData);
                    //                }
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = activityId,
                    //                    StatusId = statusId,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //                _context.SaveChanges();
                    //            }
                    //            else
                    //            {
                    //                if (containerListData != null)
                    //                {
                    //                    containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                    //                    _context.ContainerMaster.Update(containerListData);
                    //                }
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = activityId,
                    //                    StatusId = statusId,
                    //                    UserId = null,
                    //                    StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                    //                    EndDate = DateTime.UtcNow,
                    //                    Comment = comment,
                    //                    Roe = model.Roe
                    //                });
                    //                _context.SaveChanges();
                    //            }
                    //        }

                    //    }

                    //    _context.SaveChanges();

                    //    lastActivity = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId != TBLProcessing && x.ActivityId != MBLReview && x.ActivityId != TallySheet && x.ActivityId != BLRequest).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                    //    fileActivityList = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                    //    var fileActivityLists = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();
                    //    if (fileActivityLists != null)
                    //    {
                    //        if (lastActivity == carrierRequest)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = sIToCarrier,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }

                    //        }
                    //        //else if (lastActivity == BLRequest)
                    //        //{
                    //        //    var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                    //        //    if (alreadyfileExist != null)
                    //        //    {
                    //        //        _context.FileActivityLog.Update(alreadyfileExist);
                    //        //    }
                    //        //    else
                    //        //    {
                    //        //        _context.FileActivityLog.Add(new FileActivityLog
                    //        //        {
                    //        //            ContainerId = containerListData.Id,
                    //        //            ActivityId = sIToCarrier,
                    //        //            StatusId = null,
                    //        //            UserId = null,
                    //        //            StartDate = null,
                    //        //            EndDate = null,
                    //        //            Comment = null
                    //        //        });
                    //        //    }

                    //        //}
                    //        else if (lastActivity == sIToCarrier)
                    //        {

                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = finalBL,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //        else if (lastActivity == finalBL)
                    //        {

                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = preAlert,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //        else if (lastActivity == preAlert)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = permit,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }

                    //        }
                    //        else if (lastActivity == permit)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = containerListData.Id,
                    //                    ActivityId = invoices,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //    }
                    //    _context.SaveChanges();
                    //    return Json("Success");
                    //}
                    //else
                    //{
                    //    _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                    //    {
                    //        FileLogId = model.FileLogId,
                    //        ActivityId = model.ActivityId,
                    //        StatusId = selectedStatusId,
                    //        UserId = userid,
                    //        StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                    //        EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                    //        Comment = fileComments,
                    //        Roe = roeValue
                    //    });
                    //    _context.SaveChanges();

                    //    var containersListData = _context.ContainerMaster
                    //        .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                    //    _context.ContainerMaster.Add(new ContainerMaster
                    //    {
                    //        ContainerNo = model.ContainerNo,
                    //        FileId = model.FileId,
                    //        SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                    //    });
                    //    _context.SaveChanges();

                    //    var containerData = _context.ContainerMaster
                    //        .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                    //    _context.FileActivityLog.Add(new FileActivityLog
                    //    {
                    //        ContainerId = containerData.Id,
                    //        ActivityId = model.ActivityId,
                    //        StatusId = model.StatusId,
                    //        UserId = userid,
                    //        StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                    //        EndDate = DateTime.UtcNow,
                    //        Comment = model.Comment,
                    //        Roe = model.Roe
                    //    });

                    //    _context.SaveChanges();

                    //    if (fileActivityList != null)
                    //    {
                    //        if (lastActivity == carrierRequest)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == sIToCarrier).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = fileActivityList.ContainerId,
                    //                    ActivityId = sIToCarrier,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //        else if (lastActivity == sIToCarrier)
                    //        {
                    //            var activityIds = new List<string>
                    //            {
                    //                MBLReview,
                    //                TBLProcessing,
                    //                TallySheet
                    //            };
                    //            var statusIds = new List<string>
                    //            {
                    //                completed,
                    //                completedWithQuery,
                    //            };
                    //            var fileActivityLog = _context.FileActivityLog.Where(x =>
                    //                x.ContainerId == containerListData.Id &&
                    //                activityIds.Contains(x.ActivityId) &&
                    //                statusIds.Contains(x.StatusId)).ToList();
                    //            if (fileActivityLog != null)
                    //            {
                    //                var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == finalBL).FirstOrDefault();
                    //                if (alreadyfileExist != null)
                    //                {
                    //                    _context.FileActivityLog.Update(alreadyfileExist);
                    //                }
                    //                else
                    //                {
                    //                    _context.FileActivityLog.Add(new FileActivityLog
                    //                    {
                    //                        ContainerId = containerListData.Id,
                    //                        ActivityId = finalBL,
                    //                        StatusId = null,
                    //                        UserId = null,
                    //                        StartDate = null,
                    //                        EndDate = null,
                    //                        Comment = null
                    //                    });
                    //                }
                    //            }
                    //            else
                    //            {
                    //                return Json("Please complete Tally Sheet and MBL Review activity");
                    //            }


                    //        }
                    //        else if (lastActivity == finalBL)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == preAlert).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = fileActivityList.ContainerId,
                    //                    ActivityId = preAlert,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //        else if (lastActivity == preAlert)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == permit).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = fileActivityList.ContainerId,
                    //                    ActivityId = permit,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //        else if (lastActivity == permit)
                    //        {
                    //            var alreadyfileExist = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == invoices).FirstOrDefault();
                    //            if (alreadyfileExist != null)
                    //            {
                    //                _context.FileActivityLog.Update(alreadyfileExist);
                    //            }
                    //            else
                    //            {
                    //                _context.FileActivityLog.Add(new FileActivityLog
                    //                {
                    //                    ContainerId = fileActivityList.ContainerId,
                    //                    ActivityId = invoices,
                    //                    StatusId = null,
                    //                    UserId = null,
                    //                    StartDate = null,
                    //                    EndDate = null,
                    //                    Comment = null
                    //                });
                    //            }
                    //        }
                    //    }
                    //    _context.SaveChanges();
                    //    return Json("Success");
                    //}
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpPost]
        public JsonResult AddHBLActivities(HBLActivityLogViewModel model, string button, string? statusValue, string? startDateValue, string? endDateValue, string? hblComments, string? activityValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var editData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
            var wip = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var statusList = _context.StatusMaster.FirstOrDefault(x => x.Status == statusValue && x.IsActive == true && x.IsDelete == false);
            var hblList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId && x.IsActive == true && x.IsDelete == false);

            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    var hblactivityList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                    if (activityValue != null)
                    {
                        var activtyList = _context.ActivityMaster.Where(x => x.NameOfActivity == activityValue && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                        hblactivityList = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == activtyList.Id);
                        if (hblactivityList != null && hblactivityList.Status.Status != "Completed")
                        {
                            if (editData != null && model.StatusId != wip.Status)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else if (editData != null && model.StatusId == wip.Status && editData.UserId == userid)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else
                            {
                                return Json("Activity is processed by other user");
                            }
                        }

                    }
                    else
                    {
                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = model.HBLId,
                            ActivityId = model.ActivityId,
                            StatusId = wip.Id,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                            Comment = null
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");

                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    if (editData != null)
                    {
                        hblList.HBLId = model.HBLId;
                        hblList.ActivityId = model.ActivityId;
                        hblList.StatusId = selectedStatusId;
                        hblList.UserId = userId;
                        _context.HBLActivityLog.Update(hblList);
                    }
                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    var activityListData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
                    if (activityListData != null)
                    {
                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            HBLogId = activityListData.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = hblComments
                        });

                        var hblLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.Id == activityListData.Id && x.ActivityId == model.ActivityId);
                        if (hblLog != null)
                        {
                            hblLog.ActivityId = model.ActivityId;
                            hblLog.StatusId = model.StatusId;
                            hblLog.UserId = userid;
                            hblLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            hblLog.EndDate = DateTime.UtcNow;
                            hblLog.Comment = model.Comment;
                            _context.HBLActivityLog.Update(hblLog);
                        }
                    }
                    else
                    {
                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            HBLogId = hblList.Id,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = hblComments
                        });

                        var activityData = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = hblList.HBLId,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }

            }
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }
        
        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
            if (ModelState.IsValid)
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(file.FileNumber.ToUpper().Trim()));
                var currentDate = DateTime.Now;
                DateTime ETD = Convert.ToDateTime(file.ETD);
                DateTime ETA = Convert.ToDateTime(file.ETA);
                DateTime ETAPOD = Convert.ToDateTime(file.ETAPOD);
                DateTime ATD = Convert.ToDateTime(file.ATD);
                var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Carrier Request" && x.IsActive == true && x.IsDelete == false);
                var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                //var wip = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                if (role == "User")
                {
                    if (fileMaster == null)
                    {
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        var containerList = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && (x.ContainerNo == file.Container || x.Id == file.Container)).FirstOrDefault();
                        //if (file.Container != null || file.Container != "")
                        //{
                        //     containerList = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && (x.ContainerNo == file.Container || x.Id == file.Container)).FirstOrDefault();
                        //}
                        var containermaster = _context.ContainerMaster.Where(x =>  (x.FileId == fileMaster.Id && x.ContainerNo == file.Container) || (x.FileId == fileMaster.Id && x.Id == file.Container)).FirstOrDefault();
                        if (containermaster != null)
                        {
                            containermaster.FileId = fileMaster.Id;
                            containermaster.ContainerNo = file.Container;
                            _context.ContainerMaster.Update(containermaster);
                        }
                        else
                        {
                            if (fileContainer != null)
                            {
                                fileContainer.FileId = fileMaster.Id;
                                fileContainer.ContainerNo = file.Container;
                                _context.ContainerMaster.Update(fileContainer);
                            }
                            else
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    FileId = fileMaster.Id,
                                    ContainerNo = file.Container,
                                    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                });
                            }
                            //_context.ContainerMaster.Add(new ContainerMaster
                            //{
                            //    FileId = fileMaster.Id,
                            //    ContainerNo = file.Container,
                            //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                            //});
                        }

                        _context.SaveChanges();

                        var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);
                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = fileLog.Id,
                            ActivityId = carrierRequest.Id,
                            StatusId = null,
                            Comment = null,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                        });
                        _context.SaveChanges();
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.FileActivities != null)
                    {
                        foreach (FileActivityLogItem log in file.FileActivities)
                        {
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileMaster.Id,
                                ActivityId = log.ActivityId,
                                StatusId = log.StatusId,
                                Comment = log.Comment,
                                UserId = null,
                                StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                            });
                        }
                    }

                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {

                    if (fileMaster == null)
                    {
                        //wip = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container).FirstOrDefault();
                        if (containermaster != null)
                        {
                            containermaster.FileId = file.Id;
                            containermaster.ContainerNo = file.Container;
                            _context.ContainerMaster.Update(containermaster);
                        }
                        else
                        {
                            if (fileContainer != null)
                            {
                                fileContainer.FileId = fileMaster.Id;
                                fileContainer.ContainerNo = file.Container == null ? null : file.Container;
                                _context.ContainerMaster.Update(fileContainer);
                            }
                            else
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    FileId = fileMaster.Id,
                                    ContainerNo = file.Container == null ? null : file.Container,
                                    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                });
                            }
                            //_context.ContainerMaster.Add(new ContainerMaster
                            //{
                            //    FileId = fileMaster.Id,
                            //    ContainerNo = file.Container,
                            //    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                            //});
                        }

                        _context.SaveChanges();

                        var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);
                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = fileLog.Id,
                            ActivityId = carrierRequest.Id,
                            StatusId = null,
                            Comment = null,
                            UserId = null,
                            StartDate = null,
                            EndDate = null,
                        });
                        _context.SaveChanges();
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.FileActivities != null)
                    {
                        foreach (FileActivityLogItem log in file.FileActivities)
                        {
                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = fileMaster.Id,
                                ActivityId = log.ActivityId,
                                StatusId = log.StatusId,
                                Comment = log.Comment,
                                UserId = null,
                                StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                            });
                        }
                    }

                    _context.SaveChanges();

                    return Json("Success");
                }
            }
            else
            {
                return Json("Error while processing the request");
            }


        }


        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Container"] = _context.ContainerMaster.OrderBy(x => x.FileMaster.EnterDate).ToList();

            return PartialView();
        }


        //[HttpPost]
        //public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        //{
        //    string Msg = "";
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Carrier request");
        //    List<string> hblNumbers = hbl.HBLNumbers;
        //    List<HBLMaster> hblMaster = new List<HBLMaster>();
        //    HBLMaster  hblMasters = new HBLMaster();

        //    if (ModelState.IsValid)
        //    {
        //        var file = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(hbl.FileNo.ToUpper().Trim()));

        //        if (file == null)
        //        {
        //            Msg = "File does not exist. First insert the file.";
        //        }
        //        else
        //        {
        //            foreach (var hblNumber in hblNumbers)
        //            {
        //                // Perform actions with each HBL number, e.g., save to a database
        //                hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                hblMaster.Add(hblMasters);
        //            }
        //            if (hblMaster == null)
        //            {
        //                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);
        //                var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id);
        //                if (container == null)
        //                {
        //                    if (fileContainer.ContainerNo == null || fileContainer.ContainerNo == "")
        //                    {
        //                        fileContainer.FileId = file.Id;
        //                        fileContainer.ContainerNo = hbl.Container;
        //                        _context.ContainerMaster.Update(fileContainer);
        //                    }
        //                    else
        //                    {
        //                        _context.ContainerMaster.Add(new ContainerMaster
        //                        {
        //                            FileId = file.Id,
        //                            ContainerNo = hbl.Container
        //                        });
        //                    }


        //                }
        //                else
        //                {
        //                    container.FileId = file.Id;
        //                    container.ContainerNo = hbl.Container;
        //                    _context.ContainerMaster.Update(container);
        //                }
        //                _context.SaveChanges();

        //                container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);

        //                var fileLog = _context.FileActivityLog.FirstOrDefault(x => x.ContainerId == container.Id);

        //                if (fileLog == null)
        //                {
        //                    _context.FileActivityLog.Add(new FileActivityLog
        //                    {
        //                        ContainerId = container.Id,
        //                        ActivityId = carrierRequest.Id,
        //                        StatusId = null,
        //                        Comment = null,
        //                        UserId = null,
        //                        StartDate = null,
        //                        EndDate = null
        //                    });
        //                }
        //                else
        //                {
        //                    fileLog.ContainerId = container.Id;
        //                    fileLog.ActivityId = fileLog.ActivityId;
        //                    fileLog.StatusId = fileLog.StatusId;
        //                    fileLog.Comment = fileLog.Comment;
        //                    fileLog.UserId = userid;
        //                    fileLog.StartDate = fileLog.StartDate;
        //                    fileLog.EndDate = fileLog.EndDate;
        //                    _context.FileActivityLog.Update(fileLog);
        //                }

        //                if (hblMaster == null)
        //                {
        //                    foreach (var hblNumber in hblNumbers)
        //                    {
        //                        // Perform actions with each HBL number, e.g., save to a database
        //                        hblMasters = new HBLMaster
        //                        {
        //                            Id = hbl.Id,
        //                            HBLNumber = hblNumber,
        //                            ContainerId = container.Id,
        //                            Booking = hbl.BookingNo,
        //                            CustomerName = hbl.CustomerName,
        //                            EnterDate = DateTime.UtcNow,
        //                            IsActive = true,
        //                            IsDelete = false
        //                        };
        //                        _context.HBLMaster.Add(hblMasters);
        //                    }
        //                    //hblMasters = new HBLMaster
        //                    //{
        //                    //    Id = hbl.Id,
        //                    //    HBLNumber = hbl.HBL_No,
        //                    //    ContainerId = container.Id,
        //                    //    Booking = hbl.BookingNo,
        //                    //    CustomerName = hbl.CustomerName,
        //                    //    EnterDate = DateTime.UtcNow,
        //                    //    IsActive = true,
        //                    //    IsDelete = false
        //                    //};

        //                    //_context.HBLMaster.Add(hblMaster);
        //                    _context.SaveChanges();
        //                    var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
        //                    if (role == "User")
        //                    {
        //                        foreach (var hblNumber in hblNumbers)
        //                        {
        //                            var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                            HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

        //                            hBLActivityLog = new HBLActivityLog
        //                            {
        //                                HBLId = hbllist.Id,
        //                                ActivityId = hbl.HBLActivities[0].ActivityId,
        //                                StatusId = hbl.HBLActivities[0].StatusId,
        //                                UserId = userid,
        //                                Comment = hbl.HBLActivities[0].Comment,
        //                                StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
        //                                EndDate = DateTime.UtcNow
        //                            };
        //                            _context.HBLActivityLog.Add(hBLActivityLog);
        //                            _context.SaveChanges();
        //                            Msg = "HBL Inserted Successfully..!!";
        //                        }

        //                    }
        //                    else
        //                    {
        //                        foreach (var hblNumber in hblNumbers)
        //                        {
        //                            var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
        //                            HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

        //                            hBLActivityLog = new HBLActivityLog
        //                            {
        //                                HBLId = hbllist.Id,
        //                                ActivityId = hbl.HBLActivities[0].ActivityId,
        //                                StatusId = hbl.HBLActivities[0].StatusId,
        //                                UserId = null,
        //                                Comment = hbl.HBLActivities[0].Comment,
        //                                StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
        //                                EndDate = DateTime.UtcNow
        //                            };
        //                            _context.HBLActivityLog.Add(hBLActivityLog);
        //                            _context.SaveChanges();
        //                            Msg = "HBL Inserted Successfully..!!";
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    Msg = "HBL number is already added";
        //                }
        //                return Json(Msg);
        //            }
        //            else
        //            {
        //                Msg = "Duplicate HBL numbers are: " + string.Join(", ", hblMaster.Select(h => h.HBLNumber));
        //                return Json(Msg);
        //            }

        //        }
        //    }
        //    else
        //    {
        //        return Json("Error while processing the request");
        //    }
        //}

        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
            string Msg = "";
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Carrier request" && x.IsActive == true && x.IsDelete == false);
            List<string> hblNumbers = hbl.HBLNumbers;
            List<string> bookingNumbers = hbl.BookingNumbers;
            //List<string> customerNames = hbl.CustomerNames;
            List<HBLMaster> hblMaster = new List<HBLMaster>();
            HBLMaster hblMasters = new HBLMaster();

            if (ModelState.IsValid)
            {
                var file = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(hbl.FileNo.ToUpper().Trim()));

                if (file == null)
                {
                    Msg = "File does not exist. First insert the file.";
                }
                else
                {
                    if (hblNumbers.Count != bookingNumbers.Count)
                    {
                        Msg = "The count of HBL numbers and Booking numbers should be the same.";
                    }
                    //else if (bookingNumbers.Count != customerNames.Count)
                    //{
                    //    Msg = "The count of Custome Names and Booking numbers should be the same.";
                    //}
                    else
                    {
                        foreach (var hblNumber in hblNumbers)
                        {
                            // Check if the HBL number already exists in the database
                            hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                            if (hblMasters != null)
                            {
                                hblMaster.Add(hblMasters);
                            }
                        }

                        if (hblMaster.Count == 0)
                        {
                            var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);
                            var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id);

                            if (container == null)
                            {
                                if (fileContainer.ContainerNo == null || fileContainer.ContainerNo == "")
                                {
                                    fileContainer.FileId = file.Id;
                                    fileContainer.ContainerNo = hbl.Container;
                                    _context.ContainerMaster.Update(fileContainer);
                                }
                                else
                                {
                                    _context.ContainerMaster.Add(new ContainerMaster
                                    {
                                        FileId = file.Id,
                                        ContainerNo = hbl.Container
                                    });
                                }
                            }
                            else
                            {
                                container.FileId = file.Id;
                                container.ContainerNo = hbl.Container;
                                _context.ContainerMaster.Update(container);
                            }
                            _context.SaveChanges();

                            container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == file.Id && x.ContainerNo == hbl.Container);

                            var fileLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).FirstOrDefault(x => x.ContainerId == container.Id);

                            if (fileLog == null)
                            {
                                _context.FileActivityLog.Add(new FileActivityLog
                                {
                                    ContainerId = container.Id,
                                    ActivityId = carrierRequest.Id,
                                    StatusId = null,
                                    Comment = null,
                                    UserId = null,
                                    StartDate = null,
                                    EndDate = null
                                });
                            }
                            else
                            {
                                fileLog.ContainerId = container.Id;
                                fileLog.ActivityId = fileLog.ActivityId;
                                fileLog.StatusId = fileLog.StatusId;
                                fileLog.Comment = fileLog.Comment;
                                fileLog.UserId = userid;
                                fileLog.StartDate = fileLog.StartDate;
                                fileLog.EndDate = fileLog.EndDate;
                                _context.FileActivityLog.Update(fileLog);
                            }

                            for (int i = 0; i < hblNumbers.Count; i++)
                            {
                                var hblNumber = hblNumbers[i];
                                var bookingNumber = bookingNumbers[i];
                                //var customerName = customerNames[i];
                                // Check if the HBL number already exists in the database
                                hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                if (hblMasters == null)
                                {
                                    // Perform actions with each HBL number, e.g., save to a database
                                    hblMasters = new HBLMaster
                                    {
                                        //Id = hbl.Id,
                                        HBLNumber = hblNumber,
                                        ContainerId = container.Id,
                                        Booking = bookingNumber,
                                        //CustomerName = customerName,
                                        EnterDate = DateTime.UtcNow,
                                        IsActive = true,
                                        IsDelete = false
                                    };
                                    _context.HBLMaster.Add(hblMasters);
                                    _context.SaveChanges();
                                }

                                var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                                if (role == "User")
                                {
                                    var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                    HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

                                    hBLActivityLog = new HBLActivityLog
                                    {
                                        HBLId = hbllist.Id,
                                        ActivityId = hbl.HBLActivities[0].ActivityId,
                                        StatusId = hbl.HBLActivities[0].StatusId,
                                        UserId = userid,
                                        Comment = hbl.HBLActivities[0].Comment,
                                        StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                        EndDate = DateTime.UtcNow
                                    };
                                    _context.HBLActivityLog.Add(hBLActivityLog);
                                    _context.SaveChanges();

                                    Msg = "HBL Inserted Successfully..!!";
                                }
                                else
                                {

                                    var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber == hblNumber.ToUpper().Trim());
                                    HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

                                    hBLActivityLog = new HBLActivityLog
                                    {
                                        HBLId = hbllist.Id,
                                        ActivityId = hbl.HBLActivities[0].ActivityId,
                                        StatusId = hbl.HBLActivities[0].StatusId,
                                        UserId = null,
                                        Comment = hbl.HBLActivities[0].Comment,
                                        StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                        EndDate = DateTime.UtcNow
                                    };
                                    _context.HBLActivityLog.Add(hBLActivityLog);
                                    _context.SaveChanges();
                                }
                                Msg = "HBL Inserted Successfully..!!";
                            }
                        }
                        else
                        {
                            //Msg = "Duplicate HBL numbers are: " + string.Join(", ", hblMaster.Select(h => h.HBLNumber));
                            //"Duplicate HBL numbers are: " + string.Join(", ", duplicateHBLs) +
                            //"\nDuplicate booking numbers are: " + string.Join(", ", duplicateBookings);
                            //var table = "<table><tr><th>Bookings</th><th>HBL</th></tr>";
                            //for (int i = 0; i < hblMaster.Count; i++)
                            //{
                            //    table += "<tr><td>" + hblMaster[i].Booking + "</td><td>" + hblMaster[i].HBLNumber + "</td></tr>";
                            //}
                            //table += "</table>";
                            var table = "<div class='box'><div class='box-header with-border'><h3 class='box-title' style='font-weight: bold; color:black; background-color: #ffc107; font-size: 14px;'>Duplicate Booking and HBL Numbers</h3></div><div class='box-body'><table class='table table-bordered'><thead><tr><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>Bookings</th><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>HBL</th></tr></thead><tbody>";

                            for (int i = 0; i < hblMaster.Count; i++)
                            {
                                table += "<tr style='color:black; padding:0.2rem;'><td style='color:black; padding:0.2rem;'>" + hblMaster[i].Booking + "</td><td style='color:black; padding:0.2rem;'>" + hblMaster[i].HBLNumber + "</td></tr>";
                            }

                            table += "</tbody></table></div></div>";
                            Msg = table; // Return the entire table HTML

                            //Msg = "Duplicate Booking and HBL numbers:<br>" + table;
                            //return Content(Msg, "text/html");
                            return Json(Msg);
                        }
                    }
                }
            }
            else
            {
                Msg = "Error while processing the request";
            }

            return Json(Msg);
        }


        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            ViewData["Container"] = _context.ContainerMaster.OrderBy(x => x.FileMaster.EnterDate).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult InsertNewFile(FileInsertModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(file.FileNumber.ToUpper().Trim()));

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        POD = file.CountryId,
                        FileNumber = file.FileNumber,
                        ETD = Convert.ToDateTime(file.ETD).ToUniversalTime(),
                        ShippingAgent = file.ShippingAgent,
                        ShippingLine = file.ShippingLine,
                        FileContact = file.FileContact,
                        TotalBL = file.TotalHBL,
                        ETA = Convert.ToDateTime(file.ETA).ToUniversalTime(),
                        ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime(),
                        ATD = Convert.ToDateTime(file.ATD).ToUniversalTime(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                else
                {
                    fileMaster.POD = file.CountryId;
                    fileMaster.FileNumber = file.FileNumber;
                    fileMaster.ETD = Convert.ToDateTime(file.ETD).ToUniversalTime();
                    fileMaster.ShippingAgent = file.ShippingAgent;
                    fileMaster.ShippingLine = file.ShippingLine;
                    fileMaster.FileContact = file.FileContact;
                    fileMaster.TotalBL = file.TotalHBL;
                    fileMaster.ETA = Convert.ToDateTime(file.ETA).ToUniversalTime();
                    fileMaster.ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime();
                    fileMaster.ATD = Convert.ToDateTime(file.ATD).ToUniversalTime();
                    fileMaster.EnterDate = DateTime.UtcNow;
                    fileMaster.IsActive = true;
                    fileMaster.IsDelete = false;

                    _context.FileMaster.Update(fileMaster);
                }

                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);

                if (container == null)
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        FileId = fileMaster.Id,
                        ContainerNo = file.Container,
                        SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime()
                    });
                }
                else
                {
                    container.FileId = fileMaster.Id;
                    container.ContainerNo = file.Container;
                    container.SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime();

                    _context.ContainerMaster.Update(container);
                }

                _context.SaveChanges();

                return Json("Success");
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        public ActionResult GetContainers(string fileNumber)
        {
            var containers = new List<ContainerMaster>();
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            var response = new
            {
                containers = containerList
            };

            return Json(containerList);
        }


        public IActionResult FileQuery(string activityId)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetFilesQuery(string country, string fileNumber, string activity, string search, string type, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var filesData = _context.FileActivityLog
                .Include(x => x.ContainerMaster)
                    .ThenInclude(x => x.FileMaster)
                        .ThenInclude(x => x.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new FileDashModel
                {
                    Id = x.Id,
                    POD = x.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    ETD = x.ContainerMaster.FileMaster.ETD,
                    SICutOff = x.ContainerMaster.SICutOff,
                    ActivityId = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    UserId = role != "User" ? x.ApplicationUser.UserName : x.ApplicationUser.UserName,
                    StatusId = x.Status.Status,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentUser = userid,
                    Role = role
                }).AsQueryable();
            IQueryable<FileDashModel> data = filesData.AsQueryable();
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                data = data.Where(x => x.StatusId == status);
            }
            else
            {
                data = data.Where(x => x.StatusId != "Completed");
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => x.ActivityId == activity);
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            var files = data
                .Where(x => x.StatusId != "Completed" && x.StatusId != "WIP" && x.StatusId != null)
                .OrderBy(sortColumn + " " + sortColumnDirection)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = filesData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerMaster.FileMaster.FileNumber == fileNumber).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => new { x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster.FileMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();

            return Json(new { fm, hbl, sm });
        }

        public IActionResult HBLQuery(string activityId, string fileNumber)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLQuery(string country, string hblNumber, string activity, string search, string type)
        {
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            // Create a base query
            var data = _context.HBLActivityLog
                .Include(x => x.Hbl)
                .Include(x => x.Hbl.ContainerMaster.FileMaster.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    POD = x.Hbl.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                    BookingNo = x.Hbl.Booking,
                    HBLNumber = x.Hbl.HBLNumber,
                    Activity = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    User = x.ApplicationUser.UserName,
                    Status = x.Status.Status,
                    StatusId = x.StatusId,
                    Comment = x.Comment,
                    CurrentUser = userId,
                    Role = role
                }).AsQueryable();
            IQueryable<HBLDashViewModel> baseQuery = data.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(hblNumber))
            {
                baseQuery = baseQuery.Where(x => x.FileNumber.Contains(hblNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.POD == country);
            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.Activity == activity);
            }

            // Apply sorting
            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
            }
            baseQuery = baseQuery.OrderBy(sortColumn + " " + sortColumnDirection);

            // Count total records without pagination
            int totalRecords = baseQuery.Count();

            // Apply pagination and get the data
            var files = baseQuery
                .Where(x => x.Status != "Completed" && x.Status != "WIP" /*&& (role != "User" || x.User == userId)*/)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = files.Count(),
                data = files
            });


            // Return the data in the format required by DataTables

        }

        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            var sm = _context.StatusMaster.ToList();
            var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x => x.Status == "Query").AsQueryable();


            return Json(new { HBL, sm, Id });
        }

        public IActionResult HBLActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var hblActivity = _context.HBLActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var hblActivityLog = _context.HBLActivityLog.Where(x => x.Id == id && x.ActivityId == hblActivity.ActivityId).FirstOrDefault();

            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {
                HBLogId = hblActivity.Id,
                ActivityId = hblActivity.ActivityId,
                StatusId = hblActivity.StatusId,
                Comment = hblActivity.Comment,
                UserId = hblActivity.UserId,
                StartDate = hblActivity.StartDate,
                EndDate = hblActivity.EndDate,
            });
            _context.SaveChanges();

            if (hblActivity != null)
            {
                hblActivityLog.StatusId = status;
                hblActivityLog.Comment = comment;
                hblActivityLog.UserId = userid;
                hblActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                hblActivityLog.EndDate = DateTime.UtcNow;
                _context.HBLActivityLog.Update(hblActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }

        public IActionResult FileActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var fileActivity = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivityLog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.ApplicationUser).Include(x => x.Status).Where(x => x.Id == id && x.ActivityId == fileActivity.ActivityId).FirstOrDefault();

            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            {
                FileLogId = fileActivity.Id,
                ActivityId = fileActivity.ActivityId,
                StatusId = fileActivity.StatusId,
                Comment = fileActivity.Comment,
                UserId = fileActivity.UserId,
                StartDate = fileActivity.StartDate,
                EndDate = fileActivity.EndDate,

            });
            _context.SaveChanges();

            if (fileActivity != null)
            {
                fileActivityLog.StatusId = status;
                fileActivityLog.Comment = comment;
                fileActivityLog.UserId = userid;
                fileActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                fileActivityLog.EndDate = DateTime.UtcNow;
                _context.FileActivityLog.Update(fileActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var activityFile = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true).OrderBy(x => x.FileSequence).ToList();
            var activityHbl = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && (x.NameOfActivity == "HBL Processing" || x.NameOfActivity == "BL Request")).ToList();
            var activity = activityFile.Concat(activityHbl).ToList();
            ViewData["Country"] = _context.CountryMaster.ToList();
            foreach (var item in activity)
            {
                if (item.ActivityType == "File")
                {
                    item.NameOfActivity += " (F)";
                }
                else
                {
                    item.NameOfActivity += " (H)";
                }

            }
            ViewData["Activity"] = activity;
            return View();
        }

        [HttpGet]
        public IActionResult GetHblData(string id)
        {
            //const string ISTTimeZoneId = "India Standard Time";
            //var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            //var hbl = _context.HBLMaster.Where(x => x.ContainerId == id).ToList();

            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == id).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.Activity.NameOfActivity,
                StatusId = x.Status.Status,
                UserId = x.ApplicationUser.UserName,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count())
            }).ToList();

            fm = fm.OrderBy(x => x.EndDate).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.ActivityId,
                StatusId = x.StatusId,
                UserId = x.UserId,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, sgtTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, sgtTimeZone) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).ToList();

            var hblIdList = _context.HBLMaster.Where(x => x.ContainerId == id).Select(x => x.Id).ToList();
            var hbl = new List<HBLDashViewModel>();

            foreach (var hblId in hblIdList)
            {
                var hblActivityLogRecords = _context.HBLActivityLog
                    .Include(x => x.Hbl)
                    .Include(x => x.Hbl.ContainerMaster)
                    .Include(x => x.Activity)
                    .Include(x => x.Status)
                    .Include(x => x.ApplicationUser)
                    .Where(x => x.HBLId == hblId)
                    .Select(x => new HBLDashViewModel
                    {
                        Id = x.HBLId,
                        ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                        FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                        HBLNumber = x.Hbl.HBLNumber,
                        CustomerName = x.Hbl.CustomerName == null ? "" : x.Hbl.CustomerName,
                        BookingNo = x.Hbl.Booking,
                        Activity = x.Activity.NameOfActivity,
                        Status = x.Status.Status,
                        User = x.ApplicationUser.UserName == null ? "" : x.ApplicationUser.UserName,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                    }).ToList();

                hblActivityLogRecords = hblActivityLogRecords.OrderBy(x => x.EndDate).Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    ContainerNo = x.ContainerNo,
                    FileNumber = x.FileNumber,
                    HBLNumber = x.HBLNumber,
                    CustomerName = x.CustomerName,
                    BookingNo = x.BookingNo,
                    Activity = x.Activity,
                    Status = x.Status,
                    User = x.User,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, sgtTimeZone) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, sgtTimeZone) : (DateTime?)null,
                }).ToList();

                hbl.AddRange(hblActivityLogRecords);
            }
            fm = fm.OrderByDescending(x => x.EndDate).ThenBy(x => x.ActivityId).ToList();
            hbl = hbl.OrderByDescending(x => x.EndDate).ThenBy(x => x.Activity).ToList();
            return Json(new { fm, hbl, sm });
        }

        public async Task<IActionResult> UserDashboard(string activityId)
        {
            //ViewBag.StatusMaster = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityMaster"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            //ViewBag.Countries = _context.CountryMaster.ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [Authorize(Roles = "User")]
        [HttpPost]
        public IActionResult GetUserDashboard(string activity, string Country, string fileNumber, string search, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            var fileData = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                    TallySheetId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TallySheetCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().EndDate,
                    MblReviewId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                    MblReviewCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                    TblProcessingId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TblProcessingCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().EndDate,
                    TallySheetComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Comment ?? "",
                    MblReviewComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Comment ?? "",
                    TblProcessingComment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Comment ?? "",
                    CarrierRequest = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Carrier Request").FirstOrDefault().Status.Status ?? "UnAllocated",
                    CarrierRequestCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Carrier Request").FirstOrDefault().EndDate,
                    BLRequestId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "BL Request").FirstOrDefault().Status.Status ?? "UnAllocated",
                    BLRequestCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "BL Request").FirstOrDefault().EndDate,
                    TBLProcessing = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TBLProcessCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "TBL Processing").FirstOrDefault().EndDate,
                    TallySheetChecking = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().Status.Status ?? "UnAllocated",
                    TallySheetCheckingCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Tally Sheet").FirstOrDefault().EndDate,
                    SIToCarrier = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().EndDate,
                    MBLReview = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().Status.Status ?? "UnAllocated",
                    MBLReviewsCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review").FirstOrDefault().EndDate,
                    Invoice = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent").FirstOrDefault().Status.Status ?? "UnAllocated",
                    InvoiceCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent").FirstOrDefault().EndDate,
                    FinalBL = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer").FirstOrDefault().Status.Status ?? "UnAllocated",
                    FinalBLCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer").FirstOrDefault().EndDate,
                    PreAlert = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlertCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert").FirstOrDefault().EndDate,
                    Permit = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Permit").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PermitCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Permit").FirstOrDefault().EndDate,
                    LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL

                }).AsQueryable();


            IQueryable<FileDashModel> SortedData = fileData.AsQueryable();
            if (date != null)
            {
                SortedData = SortedData.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }
            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd10" || search == "etd12" || search == "etd18" || search == "si")
            {
                if (search == "etd10")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) <= DateTime.Now && (x.StatusId != "Completed"));
                }
                else if (search == "etd12")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.ETD).AddDays(-12) <= DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "etd18")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-12) > DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "Received")
                {
                    SortedData = SortedData;
                }
                else if (search == "UnAllocated")
                {
                    SortedData = SortedData.Where(x => x.StatusId == "UnAllocated");
                }
                else if (search == "si")
                {
                    SortedData = SortedData.Where(x => x.StatusId != "Completed" && x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
                else if (search == "Pending")
                {
                    SortedData = SortedData.Where(x => (x.StatusId == "Completed With Query" || x.StatusId == "Pending") && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
                else
                {
                    SortedData = SortedData.Where(x => x.StatusId == search && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            //const string ISTTimeZoneId = "India Standard Time";
            //var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            const string UTCTimeZoneId = "UTC";
            const string SGTTimeZoneId = "Singapore Standard Time";
            var utcTimeZone = TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZoneId);
            var sgtTimeZone = TimeZoneInfo.FindSystemTimeZoneById(SGTTimeZoneId);

            SortedData = SortedData.Select(x => new FileDashModel
            {
                Id = x.Id,
                FileLogId = x.FileLogId,
                EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, sgtTimeZone) : (DateTime?)null,
                FileNumber = x.FileNumber,
                POD = x.POD,
                ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, sgtTimeZone) : (DateTime?)null,
                ETAPOD = x.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAPOD.Value, sgtTimeZone) : (DateTime?)null,
                ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, sgtTimeZone) : (DateTime?)null,
                ATD = x.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ATD.Value, sgtTimeZone) : (DateTime?)null,
                SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, sgtTimeZone) : (DateTime?)null,
                ShippingLine = x.ShippingLine,
                FileContact = x.FileContact,
                FileActivityLogId = x.FileActivityLogId,
                UserId = x.UserId,
                StatusId = x.StatusId,
                ActivityId = x.ActivityId,
                ActivityType = x.ActivityType,
                ContainerNo = x.ContainerNo,
                ContainerId = x.ContainerId,
                Comment = x.Comment,
                Roe = x.Roe,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetId = x.TallySheetId,
                TallySheetCompleted = x.TallySheetCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TallySheetCompleted.Value, sgtTimeZone) : (DateTime?)null,
                MblReviewId = x.MblReviewId,
                MblReviewCompleted = x.MblReviewCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.MblReviewCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TblProcessingId = x.TblProcessingId,
                TblProcessingCompleted = x.TblProcessingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TblProcessingCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetComment = x.TallySheetComment,
                MblReviewComment = x.MblReviewComment,
                TblProcessingComment = x.TblProcessingComment,
                CarrierRequest = x.CarrierRequest,
                CarrierRequestCompleted = x.CarrierRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.CarrierRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
                BLRequestId = x.BLRequestId,
                BLRequestCompleted = x.BLRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.BLRequestCompleted.Value, sgtTimeZone) : (DateTime?)null,
                BLRequestComment = x.BLRequestComment,
                BLRequest = x.BLRequest,
                TBLProcessing = x.TBLProcessing,
                TBLProcessCompleted = x.TBLProcessCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TBLProcessCompleted.Value, sgtTimeZone) : (DateTime?)null,
                TallySheetChecking = x.TallySheetChecking,
                TallySheetCheckingCompleted = x.TallySheetCheckingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.TallySheetCheckingCompleted.Value, sgtTimeZone) : (DateTime?)null,
                SIToCarrier = x.SIToCarrier,
                SIToCarrierCompleted = x.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SIToCarrierCompleted.Value, sgtTimeZone) : (DateTime?)null,
                MBLReview = x.MBLReview,
                MBLReviewsCompleted = x.MBLReviewsCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.MBLReviewsCompleted.Value, sgtTimeZone) : (DateTime?)null,
                Invoice = x.Invoice,
                InvoiceCompleted = x.InvoiceCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.InvoiceCompleted.Value, sgtTimeZone) : (DateTime?)null,
                FinalBL = x.FinalBL,
                FinalBLCompleted = x.FinalBLCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FinalBLCompleted.Value, sgtTimeZone) : (DateTime?)null,
                PreAlert = x.PreAlert,
                PreAlertCompleted = x.PreAlertCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PreAlertCompleted.Value, sgtTimeZone) : (DateTime?)null,
                Permit = x.Permit,
                PermitCompleted = x.PermitCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PermitCompleted.Value, sgtTimeZone) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).AsQueryable();

            //SortedData = SortedData.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.ToList(),
            };

            return Json(returnObj);
        }

        public JsonResult GetDashboardCount(string? activity)
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            //var fileActivityLogs = _context.FileActivityLog
            //    .Include(x => x.ContainerMaster)
            //    .Include(x => x.Status)
            //    .Include(x => x.ApplicationUser)
            //    .ToList();

            var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                    //TallySheetId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //MblReviewId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TblProcessingId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TallySheetComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //MblReviewComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //TblProcessingComment = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "TBL Processing")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate)
                    //    .FirstOrDefault().Comment ?? "",
                    //CarrierRequest = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Carrier Request")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Carrier Request")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //BlRequestId = x.FileActivityLogs
                    //    .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "BL Request")
                    //    .OrderBy(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "BL Request")
                    //    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    //BlRequestCompleted = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "BL Request")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "BL Request")
                    //.FirstOrDefault().EndDate,
                    //TBLProcessing = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "TBL Processing")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "TBL Processing")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //TallySheetChecking = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Tally Sheet")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Tally Sheet")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //SIToCarrier = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "SI To Carrier")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //MBLReview = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "MBL Review")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "MBL Review")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //Invoice = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //FinalBL = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //PreAlert = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Pre-Alert")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Pre-Alert")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //Permit = x.FileActivityLogs
                    //.Where(y => y.Activity.NameOfActivity == "Permit")
                    //.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenByDescending(y => y.Activity.NameOfActivity == "Permit")
                    //.FirstOrDefault().Status.Status ?? "UnAllocated",
                    //LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    //TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    //TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL

                }).AsQueryable();
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }
            DashboardProdcount dp = new DashboardProdcount
            {
                Received = data.ToList().Count,
                Pending = data.Count(x => (x.StatusId == "Pending" || x.StatusId == "Completed With Query") && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                WIP = data.Count(x => x.StatusId == "WIP" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Query = data.Count(x => x.StatusId == "Query" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Completed = data.Count(x => x.StatusId == "Completed" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                UnAllocated = data.Count(x => x.StatusId == "UnAllocated"),
                siCutOff = data.Count(x => x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName && x.StatusId != "Completed"),
            };

            return Json(dp);
        }

        [HttpGet]
        public IActionResult GetContainer(string? fileNo)
        {
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNo).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            //ViewData["Container"] = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();

            return Json(new { success = "Success", containerList });
        }




        public IActionResult Adhoc()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Adhoc" && x.IsDelete == false && x.IsActive == true).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }


        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }


                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                    {
                        Id = log.Id,
                        AdhocFileId = adhocfile.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocfileActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocHBL adhochbl = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim() || x.AdhocHBLNumber == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhochbl == null)
                {
                    adhochbl = new AdhocHBL
                    {
                        Id = adhocHBLActivity.Id,
                        AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                        AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                        AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false

                    };
                    _context.AdhocHBL.Add(adhochbl);
                }

                foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                {
                    _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                    {
                        Id = log.Id,
                        AdhocHBLId = adhochbl.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocHBLActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpPost]
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container));
            }
            int filteredrecords = data.Count();

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });


        }

        [HttpPost]
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocHBLActivityLog
            .Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocHBLDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
                BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
                LastHBLHandler = User.UserName
            })
            .GroupBy(x => x.HBLNo)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking));
            }
            if (!string.IsNullOrEmpty(hblNumber))
            {
                data = data.Where(x => x.HBLNo.Contains(hblNumber));
            }

            int filteredrecords = data.Count();

            List<AdhocHBLDashModel> files = data.Select(
                x => new AdhocHBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _context.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _context.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper().ToString() == "SUPERVISOR" || RoleName.ToUpper().ToString() == "MANAGER" || RoleName.ToUpper().ToString() == "ADMIN")
            {
                return RedirectToAction("Index", "Dashboard");
            }
            else if (RoleName.ToUpper().ToString() == "USER")
            {
                return RedirectToAction("UserThread", "User");
            }
            else
            {
                return NotFound();
            }
            return View();
        }


    }
}
