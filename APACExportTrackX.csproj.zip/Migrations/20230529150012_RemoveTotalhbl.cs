﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class RemoveTotalhbl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TotalHBL",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "TotalLBL",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "TotalTBL",
                table: "HBLMaster");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TotalHBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TotalLBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TotalTBL",
                table: "HBLMaster",
                type: "int",
                nullable: true);
        }
    }
}
