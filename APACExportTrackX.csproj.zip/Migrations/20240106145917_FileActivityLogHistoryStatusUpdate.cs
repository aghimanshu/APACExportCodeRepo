﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class FileActivityLogHistoryStatusUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileAcitivityLogHistory_StatusMaster_StatusId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.AlterColumn<string>(
                name: "StatusId",
                table: "FileAcitivityLogHistory",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddForeignKey(
                name: "FK_FileAcitivityLogHistory_StatusMaster_StatusId",
                table: "FileAcitivityLogHistory",
                column: "StatusId",
                principalTable: "StatusMaster",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileAcitivityLogHistory_StatusMaster_StatusId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.AlterColumn<string>(
                name: "StatusId",
                table: "FileAcitivityLogHistory",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FileAcitivityLogHistory_StatusMaster_StatusId",
                table: "FileAcitivityLogHistory",
                column: "StatusId",
                principalTable: "StatusMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
