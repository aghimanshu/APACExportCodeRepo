﻿namespace APACExportTrackX.ViewModels
{
    public class AdhocHBLDashModel
    {

        public string Id { get; set; }
        public string CountryName { get; set; }
        public string BookingNo { get; set; }
        public string HBLNo { get; set; }
        public string LastActivityPerformed { get; set; }
        public string LastActivityStatus { get; set; }
        public string LastHBLHandler { get; set; }
        public DateTime? LastProcessedDate { get; set; }


    }
}
