﻿namespace APACExportTrackX.ViewModels
{
    public class UserWithProperties
    {
        public string UserName { get; set; }
        public string Wnsid { get; set; }
        public string CitrixId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDelete { get; set; }
        public bool? IsLDAP { get; set; }
        public bool? IsReset { get; set; }
        public string? NormalizedUserName { get; set; }
    }
}
