﻿namespace APACExportTrackX.ViewModels
{
    public class AdhocFileDashModel
    {
        public string Id { get; set; }
        public string CountryName { get; set; }
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string LastActivityPerformed { get; set; }
        public string LastActivityStatus { get; set; }
        public string LastFileHandler { get; set; }
        public DateTime? LastProcessedDate { get; set; }

    }
}
