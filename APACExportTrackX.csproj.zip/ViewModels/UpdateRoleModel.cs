﻿namespace APACExportTrackX.ViewModels
{
	public class UpdateRoleModel
	{
        public string? UserId { get; set; }
        public List<RoleList>? RoleList { get; set; }
    }
    public class RoleList
    {
        public string? RoleId { get; set; }
    }
    public class RoleNameList
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
