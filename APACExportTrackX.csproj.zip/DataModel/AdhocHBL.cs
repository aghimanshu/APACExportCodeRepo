﻿using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public class AdhocHBL
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string AdhocCountryId { get; set; } = null!;
        public string AdhocHBLNumber { get; set; } = null!;
        public string AdhocBooking { get; set; } = null!;
        public string? AdhocFileNumber { get; set; } = null;
        public string? AdhocContainer { get; set; } = null;
        public DateTime EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        [ForeignKey("AdhocCountryId")]
        public virtual CountryMaster Country { get; set; } = null!;
        public virtual ICollection<AdhocHBLActivityLog> AdhocHBLActivityLog { get; } = new List<AdhocHBLActivityLog>();
    }
}
